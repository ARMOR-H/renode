This script is meant to be used in conjunction with the coverage gathering demo, as described in: https://renode.readthedocs.io/en/latest/execution-tracing/coverage-report.html
