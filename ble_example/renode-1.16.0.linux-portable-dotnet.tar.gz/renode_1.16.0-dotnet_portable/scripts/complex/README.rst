This folder contains demos showcasing complex Renode usage scenarios.

.. note::

   Because of the nature of these demos (i.e., they require external tools, configuration or hardware) they are not automatically tested.

